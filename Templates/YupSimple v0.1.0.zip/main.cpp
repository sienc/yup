// ========================================================================== //
//
//  main.cpp
//  ---
//  YUP standardized main function
//
//  Created: 2016-08-24
//  Updated: 2016-08-24
//
//  (C) 2016 Yu-hsien Chang
//
// ========================================================================== //

#include "$AppClassName$.h"

int main(int argc, char *argv[])
{
	$AppClassName$ app(argc, argv);

	return app.exec();
}
