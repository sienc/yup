#include "$AppClassName$.h"

$AppClassName$::$AppClassName$(int argc, char *argv[])
	: yup::App(argc, argv)
{
}


$AppClassName$::~$AppClassName$()
{
}

bool $AppClassName$::init()
{
	return true;
}

bool $AppClassName$::update()
{
	return false;
}

void $AppClassName$::shutdown()
{
}
