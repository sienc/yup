// ========================================================================== //
//
//  ShaderCollection.cpp
//  ---
//
//  Created: 2016-08-24
//  Updated: 2016-08-24
//
//  (C) 2016 Yu-hsien Chang
//
// ========================================================================== //

#ifdef YUP_INCLUDE_GLEW

#include "ShaderCollection.h"

BEGIN_NAMESPACE_YUP_GL

ShaderCollection Shader;

END_NAMESPACE_YUP_GL

#endif // YUP_INCLUDE_GLEW